
            fetch('../json/second.json')
               .then(Response => Response.json())
       
               .then(sdata =>{
                circleimage(sdata)
                best(sdata)
                imagess(sdata)
                imagess2(sdata)
                you(sdata)
                sqe(sdata)
                   
               })


               function circleimage(sdata){
            let s_image=" "
          for(i=0;i<sdata.circleimage.length;i++){
            s_image+=`<img class="cir" src="Images/${sdata.circleimage[i]}">`
          }
          let circle=document.querySelector(".circle");
          circle.innerHTML=s_image;
          size()
        }
        function size(){
            let cir=document.querySelectorAll(".cir")
          cir.forEach(element => {
            element.style.height="150px"
            element.style.width="150px"
            element.style.borderRadius="100%"
            element.style.marginTop="80px"
          });
        }

        function best(sdata){
            let s_list=""
                s_list +=`<h1 id="bes">${sdata.best[0]}</h1>`
        
            document.getElementById('best').innerHTML=s_list;

            let bes=document.querySelectorAll("#bes");
          bes.forEach(abc=>{
            abc.style.width="auto"
            abc.style.fontSize="40px"
            abc.style.color="#ff6b6b"
            abc.style.marginTop="60px"
            abc.style.textAlign="center"
          })

        }


        function imagess(data){
            let box=document.querySelectorAll(".box")
        var i=0
        let p=`<p>${data.bestseller.heading}</p>`
        box.forEach(ele=>{
           
            
            ele.style.height="400px"
            ele.style.width="300px"
            ele.style.boxShadow="3px 3px 5px gray"
            ele.style.marginBottom="10px"
           
            let img=`<img id="image1" src="Images/${data.bestseller.images[i]}">`
            let p=`<p class="text">${data.bestseller.price[i]}</p> <p class="te">${data.bestseller.items[i]}</p>`
            

            ele.innerHTML=img+p
            i++

        })
        let image1=document.querySelectorAll("#image1")
        image1.forEach(ele=>{
            ele.style.height="330px"
            ele.style.width="300px"
            
        })
        let text=document.querySelectorAll(".text")
        text.forEach(ele=>{
            ele.style.fontSize="25px"
            ele.style.fontWeight="bolder"
            ele.style.color="#ff6b6b"
            ele.style.margin="0px 15px "
            
        })

        let te=document.querySelectorAll(".te")
        te.forEach(ele=>{
            ele.style.fontSize="17px"
            ele.fontWeight="20px"
            ele.style.color="black"
            ele.style.margin="0px 15px "
        })
        }


//box2

        
        function imagess2(data){
            let box2=document.querySelectorAll(".box2")
        var i=0
        let p=`<p>${data.bestseller2.heading}</p>`
        box2.forEach(ele=>{
           
            
            ele.style.height="400px"
            ele.style.width="300px"
            ele.style.boxShadow="3px 3px 5px gray"
            ele.style.marginBottom="10px"
           
            let img=`<img id="image12" src="Images/${data.bestseller2.images[i]}">`
            let p=`<p class="text2">${data.bestseller2.price[i]}</p> <p class="te2">${data.bestseller2.items[i]}</p>`
            

            ele.innerHTML=img+p
            i++

        })
        let image12=document.querySelectorAll("#image12")
        image12.forEach(ele=>{
            ele.style.height="330px"
            ele.style.width="300px"
            
        })
        let text2=document.querySelectorAll(".text2")
        text2.forEach(ele=>{
            ele.style.fontSize="25px"
            ele.style.fontWeight="bolder"
            ele.style.color="#ff6b6b"
            ele.style.margin="0px 15px "
            
        })

        let te2=document.querySelectorAll(".te2")
        te2.forEach(ele=>{
            ele.style.fontSize="17px"
            ele.fontWeight="20px"
            ele.style.color="black"
            ele.style.margin="0px 15px "
        })
        }


        function you(sdata){
            let s_list=""
                s_list =`<h1 id="you">${sdata.you[0]}</h1>`
        
            document.getElementById('you').innerHTML=s_list;

            let you=document.querySelectorAll("#you");
          you.forEach(abc=>{
            abc.style.width="auto"
            abc.style.fontSize="40px"
            abc.style.color="#ff6b6b"
            abc.style.marginTop="60px"
            abc.style.textAlign="center"
          })

        }

        function sqe(sdata){
            let s_image=" "
          for(i=0;i<sdata.sqe.length;i++){
            s_image+=`<img class="sqe1" src="Images/${sdata.sqe[i]}">`
          }
          let sqe2=document.querySelector(".sqe2");
          sqe2.innerHTML=s_image;
          sizeq()
        }
        function sizeq(){
            let sqe1=document.querySelectorAll(".sqe1")
          sqe1.forEach(element => {
            element.style.height="350px"
            element.style.width="350px"
            element.style.marginTop="80px"
          });
        }

let express = require  ("express");
let path=require("path");
let app=express();
let hbs=require("hbs");  
// let db = require("./db/conn"); 
let bodyParser=require("body-parser");

//console.log(path.join(__dirname,"../public")); 
let static_path=path.join(__dirname,"../public") 
let template_path=path.join(__dirname,"../templates/views") 

const mongoose = require('mongoose');
mongoose.connect("mongodb+srv://chandu2003:2003@cluster0.kszhpn2.mongodb.net/test");



var db=mongoose.connection;
db.on('error', console.log.bind(console, "connection error"));
db.once('open', function(callback){
    console.log("connection succeeded");
})

   
app.use(express.static(static_path))
app.use(bodyParser.urlencoded({
    extended: true
}));

app.set("view engine","hbs");
app.set("views",template_path)

app.post('/sign_up', function(req,res){
    var name = req.body.name;
    var email =req.body.email;
    var pass = req.body.password;
    var phone =req.body.phone;
  
    var data = {
        "name": name,
        "email":email,
        "password":pass,
        "phone":phone
    }
db.collection('details').insertOne(data,function(err, collection){
        if (err) throw err;
        console.log("Record inserted Successfully");
              
    });
          
    res.render('signup_success');
})

app.get('/',function(req,res){
    res.set({
        'Access-control-Allow-Origin': '*'
        });
    res.render('index');
    })


app.listen(3000 ,()=>{
    console.log("server server server  ")
} )
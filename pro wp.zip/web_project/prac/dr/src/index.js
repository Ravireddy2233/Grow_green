const express = require ("express")
const app = express();
const path = require ("path")
console.log(__dirname)
const hbs=require("hbs")


//view engine
app.set("view engine","hbs")

app.set("views",path.join(__dirname,"../templates/views"))

//for joining images and css 

app.use(express.static (path.join(__dirname, "../public")))

hbs.registerPartials(path.join(__dirname,"../templates/partials"))


    app.get("/",(req,res)=>{
        res.render("first")
    })

    app.get("/second",(req,res)=>{
       
        res.sendFile(path.join(__dirname,"../public/second.html"))
       })


    app.get("/close",(req,res)=>{
        res.render("close")
     })
 
  
   
 


app.listen("4000", ()=>{console.log("connected..")

})